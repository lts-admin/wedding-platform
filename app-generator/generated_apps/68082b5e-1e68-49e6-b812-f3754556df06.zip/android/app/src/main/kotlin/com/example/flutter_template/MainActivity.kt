package com.example.flutter_template

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
